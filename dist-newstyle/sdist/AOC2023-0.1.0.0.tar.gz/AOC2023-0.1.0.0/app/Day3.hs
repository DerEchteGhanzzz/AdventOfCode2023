module Day3 (day3) where
import AocUtils
import Data.List.Split
import Text.Regex

type PartNumber = Int

day3 :: AocDay
day3 = MkDay 3 solveA solveB

solveA :: [String] -> String
solveA input = show . map (matchRegex) input
  where
    p = mkRegex "[^\d-]+"

solveB :: [String] -> String
solveB input = show input