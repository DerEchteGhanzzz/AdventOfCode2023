module DayX (dayX) where
import AocUtils

dayX :: AocDay
dayX = MkDay 0 solveA solveB

solveA :: [String] -> String
solveA input = show input

solveB :: [String] -> String
solveB input = show input